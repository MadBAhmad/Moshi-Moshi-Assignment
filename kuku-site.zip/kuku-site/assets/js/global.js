$(document).ready(function () {
  /*header background*/
  $(function () {
    $(window).on("scroll", function () {
      if ($(window).scrollTop() >= 50) {
        $("header").addClass("active");
      } else {
        $("header").removeClass("active");
      }
    });
  });
  /*header background*/

  /*Product Slider*/
  $(".products-slider").owlCarousel({
    loop: true,
    margin: 30,
    nav: false,
    center: true,
    dots: false,
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 3,
      },
      1000: {
        items: 4.2,
      },
    },
  });
  /*Product Slider*/

  /*Category Slider*/
  const btnCategory = document.querySelector(".btnCategory");

  $(".category-slider").owlCarousel({
    loop: true,
    margin: 30,
    nav: true,
    navText: [
      "<img src='assets/images/arrow-left.svg' class='btn-prev'></img>",
      "<img src='assets/images/arrow-right.svg' class='btn-next'></img>",
    ],
    center: true,
    dots: false,
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 3,
      },
      1000: {
        items: 3.5,
      },
      1366: {
        items: 4.5,
      },
    },
  });

  function updateButtonValue() {
    const currentItem = document.querySelector(".owl-item.center .prod_tag");
    if (currentItem) {
      btnCategory.value = currentItem.textContent;
      btnCategory.textContent = currentItem.textContent;
    }
  }

  $(".category-slider").on("translated.owl.carousel", function (event) {
    updateButtonValue();
  });

  updateButtonValue();

  /*Category Slider*/
});
